
$(document).ready(function(){
  /** dashboard*/
     $("#dash").click(function(){
      if($("ul.nav > li > a").hasClass('active'))
      {
         $("ul.nav > li > a").removeClass('active');
      }
     
      $("#dash").addClass('active');
        var header = $(this).text();
        $("#page-wrapper-header").text(header);
        $("#load").load("dashboard.html");
      
    });
    /** addProduct*/
    
    $("#addProd").click(function(){
      if($("ul.nav > li > a").hasClass('active'))
      {
         $("ul.nav > li > a").removeClass('active');
      }

        $("#addProd").addClass('active');
        // var header = $(this).text();
        $("#page-wrapper-header").text("Add product");
        $("#load").load("addProducts.html");
    });
    /** initial load*/
    $("#load").load("dashboard.html");
    
    
    // $("side-menu")
//  $('#menu a[href]').on('click', function() {
//         sessionStorage.setItem('menu', $(this).attr('href'));
//     });
//     if (!sessionStorage.getItem('menu')) {
//         $('#side-menu #dash').addClass('active');
//     } else {
//         $('#side-menu a[href=\'' + sessionStorage.getItem('side-menu') + '\']').parents('li').addClass('active open');
//     }

});

